export class UserResponseDTO {
  id: number;
  username: string;
  displayName: string;
  avatarUrl?: string;
}
