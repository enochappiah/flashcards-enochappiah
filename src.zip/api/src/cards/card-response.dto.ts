export class CardResponseDto {
  id: string;
  front: string;
  back: string;
  createdAt: Date;
  deckId: string;
}
